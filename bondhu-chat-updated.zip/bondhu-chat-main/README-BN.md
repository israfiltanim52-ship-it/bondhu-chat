# Bondhu Chat — Updated Green & Ivory UI

এই সংস্করণে আগের Firebase project `bondhu-chat-b76d6` এবং বিদ্যমান Email/Password authentication configuration রাখা হয়েছে।

## এই আপডেটে
- Emerald Green + Soft Ivory ডিজাইনকে default করা হয়েছে।
- Home, Chats, Calls এবং Profile পেজের switching ঠিক করা হয়েছে।
- Bottom navigation-এর active state ও accessibility labels ঠিক করা হয়েছে।
- Chat list ও friend search result-এর অনুপস্থিত style যোগ করা হয়েছে।
- Sent/received message bubble-এর class mismatch ঠিক করা হয়েছে।
- Toast notification container যোগ করা হয়েছে।
- PWA manifest-এর theme color আপডেট করা হয়েছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই সংস্করণে টেক্সট মেসেজিং ও ইমেইল দিয়ে ব্যবহারকারী খোঁজার ব্যবস্থা আছে।
- Voice button এখনো পরবর্তী সংস্করণের placeholder; বাস্তব voice recording/upload এখানে সক্রিয় নয়।
- Audio/video calling, push notifications, ছবি/ফাইল পাঠানো, group chat এবং end-to-end encryption এখনো নেই।
- প্রকাশের আগে Firebase Console-এর Authentication, Firestore Rules এবং দুইটি test account দিয়ে পরীক্ষা করুন।

## Firebase নিরাপত্তা
- আগের Firebase project মুছবেন না।
- Authentication > Users থেকে পুরোনো account মুছবেন না।
- `firestore.rules` ও `storage.rules` যাচাই না করে production-এ প্রয়োগ করবেন না।
- Firebase web config client-side-এ থাকে; আসল নিরাপত্তা Rules ও Authentication সেটিংসের ওপর নির্ভর করে।

## GitHub-এ আপলোড
1. ZIP extract করুন।
2. `bondhu-chat-main` ফোল্ডারের ভেতরের ফাইলগুলো repository root-এ upload/replace করুন।
3. `index.html`, `app.js`, `style.css`, `manifest.json`, `sw.js` যেন root-এ থাকে।
4. Commit changes করুন।
5. GitHub Pages চালু থাকলে site refresh করুন; পুরোনো cache থাকলে browser cache/site data clear করুন।
